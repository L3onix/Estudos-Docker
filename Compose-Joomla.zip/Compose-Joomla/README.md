Para dar deploy neste arquivo ".yml" deverá utilizar um dos 2 comando baixo, dependendo de como pretende rodar o compose.
+ #docker-compose -f docker-compose.yml up
+ #docker stack deploy -c docker-compose.yml compose-joomla